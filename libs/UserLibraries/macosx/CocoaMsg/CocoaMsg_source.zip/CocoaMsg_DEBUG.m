
#import <objc/message.h>
#import <Foundation/Foundation.h>

extern void PB_DEBUGGER_SendError(const char * message);
extern void PB_DEBUGGER_SendWarning(const char * message);

id PB_CocoaMsg_DEBUG_(void **args)
{
    args++;
    id rec = *args++;
    
    char buf[256];
    char *src, *dst, c;
    
    src = *args;
    int charSize = src[1] ? 1 : 2;
    
    if (rec == nil){
        // retrieve class name
        dst = buf;
        do {
            c = *src;
            *dst++ = c;
            src += charSize;
        } while (c != 0 && c != 32);
        if (c == 32){
            dst--;
            *dst = 0;
            rec = objc_lookUpClass(buf);
            if (rec == 0){
                char * msg;
                asprintf(&msg, "Class \"%s\" does not exist.", buf);
                PB_DEBUGGER_SendError(msg);
                free(msg);
            }
            *args = src;
        }
    }
    
    dst = buf;
    char valType[8];
    int num_args = 0;
    while ((src = *args++)){
        do {
            c = *src;
            *dst++ = c;
            src += charSize;
        } while (c);
        dst -= 2;
        c = *dst;
        if (c == '@' || c == '$'){
            *dst = 0;
        } else {
            c = 0;
            dst++;
        }
        valType[num_args++] = c;
    }
    if (*--dst != ':'){
        if (--num_args == 0) *++dst = c;
    }
    SEL selector = sel_registerName(buf);
    
    if (rec == nil){
        PB_DEBUGGER_SendWarning("Object is nil.");
    } else if ([rec respondsToSelector:selector] == NO){
        char * msg;
        asprintf(&msg, "Object does not respond to method \"%s\" .", buf);
        PB_DEBUGGER_SendError(msg);
        free(msg);
    }
    
    for (int i = 0; i < num_args; i++) if (*args++ == 0 && valType[i]){
        char * msg;
        asprintf(&msg, "Pointer for argument %i is 0.", i + 1);
        PB_DEBUGGER_SendError(msg);
        free(msg);
    }
    return nil;
}

id PB_oMsg_DEBUG (void * ret, void * rec, void * s1)
{ return PB_CocoaMsg_DEBUG_((void*[]){ret, rec, s1,0, 0}); }
id PB_oMsg2_DEBUG(void * ret, void * rec, void * s1, void * a1)
{ return PB_CocoaMsg_DEBUG_((void*[]){ret, rec, s1,0, a1}); }
id PB_oMsg3_DEBUG(void * ret, void * rec, void * s1, void * a1, void * s2, void * a2)
{ return PB_CocoaMsg_DEBUG_((void*[]){ret, rec, s1,s2,0, a1,a2}); }
id PB_oMsg4_DEBUG(void * ret, void * rec, void * s1, void * a1, void * s2, void * a2, void * s3, void * a3)
{ return PB_CocoaMsg_DEBUG_((void*[]){ret, rec, s1,s2,s3,0, a1,a2,a3}); }
id PB_oMsg5_DEBUG(void * ret, void * rec, void * s1, void * a1, void * s2, void * a2, void * s3, void * a3, void * s4, void * a4)
{ return PB_CocoaMsg_DEBUG_((void*[]){ret, rec, s1,s2,s3,s4,0, a1,a2,a3,a4}); }
id PB_oMsg6_DEBUG(void * ret, void * rec, void * s1, void * a1, void * s2, void * a2, void * s3, void * a3, void * s4, void * a4, void * s5, void * a5)
{ return PB_CocoaMsg_DEBUG_((void*[]){ret, rec, s1,s2,s3,s4,s5,0, a1,a2,a3,a4,a5}); }
id PB_oMsg7_DEBUG(void * ret, void * rec, void * s1, void * a1, void * s2, void * a2, void * s3, void * a3, void * s4, void * a4, void * s5, void * a5, void * s6, void * a6)
{ return PB_CocoaMsg_DEBUG_((void*[]){ret, rec, s1,s2,s3,s4,s5,s6,0, a1,a2,a3,a4,a5,a6}); }
id PB_oMsg8_DEBUG(void * ret, void * rec, void * s1, void * a1, void * s2, void * a2, void * s3, void * a3, void * s4, void * a4, void * s5, void * a5, void * s6, void * a6, void * s7, void * a7)
{ return PB_CocoaMsg_DEBUG_((void*[]){ret, rec, s1,s2,s3,s4,s5,s6,s7,0, a1,a2,a3,a4,a5,a6,a7}); }
id PB_oMsg9_DEBUG(void * ret, void * rec, void * s1, void * a1, void * s2, void * a2, void * s3, void * a3, void * s4, void * a4, void * s5, void * a5, void * s6, void * a6, void * s7, void * a7, void * s8, void * a8)
{ return PB_CocoaMsg_DEBUG_((void*[]){ret, rec, s1,s2,s3,s4,s5,s6,s7,s8,0, a1,a2,a3,a4,a5,a6,a7,a8}); }