
#import <objc/message.h>
#import <Foundation/Foundation.h>

id PB_CocoaMsg_(void **args)
{
    id result = nil;
    
    void *ret = *args++;
    id rec = *args++;

    char buf[256];
    char *src, *dst, c;
    
    src = *args;
    int charSize = src[1] ? 1 : 2;
    
    if (rec == nil){
        // retrieve class name
        dst = buf;
        do {
            c = *src;
            *dst++ = c;
            src += charSize;
        } while (c != 0 && c != 32);
        if (c == 32){
            dst--;
            *dst = 0;
            rec = objc_lookUpClass(buf);
            *args = src;
        }
    }
     
    dst = buf;
    char valType[8];
    int num_args = 0;
    BOOL byRefUsed = ret != 0;
    while ((src = *args++)){
        do {
            c = *src;
            *dst++ = c;
            src += charSize;
        } while (c);
        dst -= 2;
        c = *dst;
        if (c == '@' || c == '$'){
            *dst = 0;
            byRefUsed = YES;
        } else {
            c = 0;
            dst++;
        }
        valType[num_args++] = c;
    }
    if (*--dst != ':'){
        if (--num_args == 0) *++dst = c;
    }
    SEL selector = sel_registerName(buf);
    
    Method method = class_getInstanceMethod(object_getClass(rec), selector);
    if (method)
    {
        if (byRefUsed == NO && num_args <= 4){
            if (num_args == 0) return objc_msgSend(rec, selector);
            if (num_args == 1) return objc_msgSend(rec, selector, args[0]);
            if (num_args == 2) return objc_msgSend(rec, selector, args[0], args[1]);
            if (num_args == 3) return objc_msgSend(rec, selector, args[0], args[1], args[2]);
            if (num_args == 4) return objc_msgSend(rec, selector, args[0], args[1], args[2], args[3]);
        }
        
        NSMethodSignature * sig = [NSMethodSignature signatureWithObjCTypes:method_getTypeEncoding(method)];
        NSInvocation * inv = [NSInvocation invocationWithMethodSignature:sig];
        
        [inv setSelector:selector];
        void * arg;
        for (int i = 0; i < num_args; i++){
            c = valType[i];
            if ((arg = *args++)||c == 0){
                if (c == '$'){
                    if (charSize == 1){
                        arg = [NSString stringWithCString:arg encoding:NSISOLatin1StringEncoding];
                    } else {
                        arg = [NSString stringWithFormat:@"%S", (const unichar *)arg];
                    }
                }
                [inv setArgument:(c == '@' ? arg : &arg) atIndex:i + 2];
            }
        }
        [inv invokeWithTarget:rec];
        int ret_len = [sig methodReturnLength];
        if (ret_len > 0){
            if (ret){
                [inv getReturnValue:ret];
            } else if (ret_len <= sizeof(result)){
                [inv getReturnValue:&result];
            }
        }
    }
     
    return result;
}

id PB_oMsg (void * ret, void * rec, void * s1)
{ return PB_CocoaMsg_((void*[]){ret, rec, s1,0, 0}); }
id PB_oMsg2(void * ret, void * rec, void * s1, void * a1)
{ return PB_CocoaMsg_((void*[]){ret, rec, s1,0, a1}); }
id PB_oMsg3(void * ret, void * rec, void * s1, void * a1, void * s2, void * a2)
{ return PB_CocoaMsg_((void*[]){ret, rec, s1,s2,0, a1,a2}); }
id PB_oMsg4(void * ret, void * rec, void * s1, void * a1, void * s2, void * a2, void * s3, void * a3)
{ return PB_CocoaMsg_((void*[]){ret, rec, s1,s2,s3,0, a1,a2,a3}); }
id PB_oMsg5(void * ret, void * rec, void * s1, void * a1, void * s2, void * a2, void * s3, void * a3, void * s4, void * a4)
{ return PB_CocoaMsg_((void*[]){ret, rec, s1,s2,s3,s4,0, a1,a2,a3,a4}); }
id PB_oMsg6(void * ret, void * rec, void * s1, void * a1, void * s2, void * a2, void * s3, void * a3, void * s4, void * a4, void * s5, void * a5)
{ return PB_CocoaMsg_((void*[]){ret, rec, s1,s2,s3,s4,s5,0, a1,a2,a3,a4,a5}); }
id PB_oMsg7(void * ret, void * rec, void * s1, void * a1, void * s2, void * a2, void * s3, void * a3, void * s4, void * a4, void * s5, void * a5, void * s6, void * a6)
{ return PB_CocoaMsg_((void*[]){ret, rec, s1,s2,s3,s4,s5,s6,0, a1,a2,a3,a4,a5,a6}); }
id PB_oMsg8(void * ret, void * rec, void * s1, void * a1, void * s2, void * a2, void * s3, void * a3, void * s4, void * a4, void * s5, void * a5, void * s6, void * a6, void * s7, void * a7)
{ return PB_CocoaMsg_((void*[]){ret, rec, s1,s2,s3,s4,s5,s6,s7,0, a1,a2,a3,a4,a5,a6,a7}); }
id PB_oMsg9(void * ret, void * rec, void * s1, void * a1, void * s2, void * a2, void * s3, void * a3, void * s4, void * a4, void * s5, void * a5, void * s6, void * a6, void * s7, void * a7, void * s8, void * a8)
{ return PB_CocoaMsg_((void*[]){ret, rec, s1,s2,s3,s4,s5,s6,s7,s8,0, a1,a2,a3,a4,a5,a6,a7,a8}); }